/**
 * SEAF plugin for draw.io desktop runtime.
 * Runtime script version: 0.1.9
 * Uses main-process IPC for config, command execution and logs.
 */
Draw.loadPlugin(function(ui)
{
	var state = {
		configPath: null,
		config: null,
		commandsById: {},
		runtimeVersion: 'unknown',
		manualIndicators: {},
		autoIndicatorsByJob: {},
		systemUpdateInProgress: false,
		actionsRegistered: false,
		mainMenuRegistered: false,
		contextMenuRegistered: false,
		logging: {
			level: 'info',
			extendedDebug: false,
			includePayload: false
		}
	};

	function requestAsync(msg)
	{
		if (typeof electron === 'undefined' || electron == null || typeof electron.request !== 'function')
		{
			return Promise.reject(new Error('Electron IPC bridge is unavailable'));
		}

		return new Promise(function(resolve, reject)
		{
			electron.request(msg, function(data)
			{
				resolve(data);
			}, function(errMsg, errObj)
			{
				reject(errObj || new Error(errMsg));
			});
		});
	}

	function maskSensitive(value)
	{
		if (value == null || typeof value !== 'object')
		{
			return value;
		}

		if (Array.isArray(value))
		{
			return value.map(maskSensitive);
		}

		var out = {};
		var secretRegex = /(token|secret|password|apikey|api_key|auth|cookie)/i;

		for (var key in value)
		{
			if (Object.prototype.hasOwnProperty.call(value, key))
			{
				out[key] = secretRegex.test(key) ? '***' : maskSensitive(value[key]);
			}
		}

		return out;
	}

	function safeLogData(data)
	{
		return state.logging.includePayload ? maskSensitive(data) : null;
	}

	async function writeLog(level, message, data)
	{
		var payload = {
			action: 'writeSeafPluginLog',
			configPath: state.configPath,
			level: level,
			message: message,
			data: safeLogData(data)
		};

		try
		{
			await requestAsync(payload);
		}
		catch (e)
		{
			try
			{
				console.log('[SEAF]', level, message, data || '');
			}
			catch (ignored)
			{
				// ignore fallback logging errors
			}
		}
	}

	function showInfo(message)
	{
		mxUtils.alert(message);
	}

	function showError(message)
	{
		mxUtils.alert(message);
	}

	function buildRestartRequiredMessage(result)
	{
		var version = null;
		if (result && result.payload && typeof result.payload.version === 'string' && result.payload.version.trim().length > 0)
		{
			version = result.payload.version.trim();
		}
		var line1 = version ? ('Плагин обновлен до версии ' + version) : 'Плагин успешно обновлен';
		return line1 + '\nИзменения вступят в силу после перезапуска приложения draw.io';
	}

	function getUpdateUiOutcome(result)
	{
		var payload = (result && typeof result.payload === 'object' && result.payload != null) ? result.payload : {};
		var status = (typeof payload.status === 'string' && payload.status.trim().length > 0) ?
			payload.status.trim() : (typeof result.status === 'string' ? result.status.trim() : '');
		if (status === 'updated')
		{
			return {
				level: 'info',
				message: buildRestartRequiredMessage(result)
			};
		}
		if (status === 'already_up_to_date')
		{
			var latestMessage = (typeof result.message === 'string' && result.message.trim().length > 0) ?
				result.message.trim() :
				('Установлена актуальная версия ' + ((payload && payload.version) ? payload.version : 'плагина'));
			return {
				level: 'info',
				message: latestMessage
			};
		}

		// Backward compatibility: unknown success payload keeps restart-required behavior.
		return {
			level: 'info',
			message: buildRestartRequiredMessage(result)
		};
	}

	function formatCommandError(commandId, message)
	{
		var id = commandId || 'unknownCommand';
		var msg = (message != null && String(message).trim().length > 0) ? String(message) : 'unknown error';
		return id + ': ' + msg;
	}

	function getIndicatorConfig(command)
	{
		var indicator = (command && typeof command.indicator === 'object') ? command.indicator : {};
		return {
			enabled: indicator.enabled === true,
			type: indicator.type === 'percent' ? 'percent' : 'spinner',
			timeoutMs: Number.isFinite(indicator.timeoutMs) && indicator.timeoutMs > 0 ? Math.round(indicator.timeoutMs) : null,
			allowStop: indicator.allowStop === true
		};
	}

	function createIndicatorUi(params)
	{
		var overlay = document.createElement('div');
		overlay.style.position = 'fixed';
		overlay.style.left = '16px';
		overlay.style.bottom = '16px';
		overlay.style.minWidth = '280px';
		overlay.style.maxWidth = '420px';
		overlay.style.padding = '10px 12px';
		overlay.style.background = '#ffffff';
		overlay.style.border = '1px solid #d0d0d0';
		overlay.style.borderRadius = '6px';
		overlay.style.boxShadow = '0 2px 8px rgba(0,0,0,0.2)';
		overlay.style.zIndex = '99999';
		overlay.style.fontFamily = 'Arial, sans-serif';
		overlay.style.fontSize = '12px';

		var title = document.createElement('div');
		title.style.fontWeight = 'bold';
		title.style.marginBottom = '6px';
		title.textContent = params.title || 'SEAF task in progress';
		overlay.appendChild(title);

		var statusLine = document.createElement('div');
		statusLine.textContent = params.message || 'Running...';
		statusLine.style.marginBottom = '8px';
		overlay.appendChild(statusLine);

		var progressWrap = document.createElement('div');
		progressWrap.style.height = '6px';
		progressWrap.style.background = '#efefef';
		progressWrap.style.borderRadius = '3px';
		progressWrap.style.overflow = 'hidden';
		progressWrap.style.display = params.type === 'percent' ? 'block' : 'none';

		var progressFill = document.createElement('div');
		progressFill.style.height = '100%';
		progressFill.style.width = '0%';
		progressFill.style.background = '#4c8bf5';
		progressWrap.appendChild(progressFill);
		overlay.appendChild(progressWrap);

		var controls = document.createElement('div');
		controls.style.marginTop = '8px';
		controls.style.textAlign = 'right';
		if (params.allowStop === true && typeof params.onStop === 'function')
		{
			var stopBtn = document.createElement('button');
			stopBtn.textContent = 'Остановить';
			stopBtn.onclick = params.onStop;
			controls.appendChild(stopBtn);
		}
		overlay.appendChild(controls);
		document.body.appendChild(overlay);

		var timeoutId = null;
		if (Number.isFinite(params.timeoutMs) && params.timeoutMs > 0 && typeof params.onTimeout === 'function')
		{
			timeoutId = window.setTimeout(params.onTimeout, params.timeoutMs);
		}

		return {
			update: function(next)
			{
				var nextMessage = next && next.message != null ? String(next.message) : '';
				if (nextMessage.length > 0)
				{
					statusLine.textContent = nextMessage;
				}

				var nextProgress = next && Number.isFinite(next.progress) ? Math.max(0, Math.min(100, Math.round(next.progress))) : null;
				if (nextProgress != null)
				{
					progressWrap.style.display = 'block';
					progressFill.style.width = nextProgress + '%';
				}
				else if (params.type === 'spinner')
				{
					progressWrap.style.display = 'none';
				}
			},
			stop: function()
			{
				if (timeoutId != null)
				{
					window.clearTimeout(timeoutId);
				}
				if (overlay.parentNode != null)
				{
					overlay.parentNode.removeChild(overlay);
				}
			}
		};
	}

	async function detectRuntimeVersion()
	{
		var fallback = 'unknown';
		try
		{
			if (state.config && state.config.plugin && typeof state.config.plugin.runtimeVersion === 'string' &&
				state.config.plugin.runtimeVersion.trim().length > 0)
			{
				fallback = state.config.plugin.runtimeVersion.trim();
			}

			if (!state.configPath || typeof state.configPath !== 'string')
			{
				return fallback;
			}

			var runtimeVersionPath = state.configPath.replace(/[\\\/]conf[\\\/]plugin\.yaml$/i, '/runtime/version.json');
			if (runtimeVersionPath === state.configPath)
			{
				return fallback;
			}

			var raw = await requestAsync({
				action: 'readFile',
				filename: runtimeVersionPath,
				encoding: 'utf8'
			});
			var parsed = JSON.parse(raw);
			if (parsed && typeof parsed.version === 'string' && parsed.version.trim().length > 0)
			{
				return parsed.version.trim();
			}
		}
		catch (e)
		{
			// ignore metadata read errors and keep fallback
		}

		return fallback;
	}

	function getRuntimeVersionLabel()
	{
		return 'SEAF Runtime v' + (state.runtimeVersion || 'unknown');
	}

	function getSelectionPayload()
	{
		var graph = ui.editor.graph;
		var cells = graph.getSelectionCells();
		var out = [];

		for (var i = 0; i < cells.length; i++)
		{
			var cell = cells[i];
			out.push({
				id: cell.id,
				isVertex: graph.model.isVertex(cell),
				isEdge: graph.model.isEdge(cell),
				label: graph.convertValueToString(cell),
				style: graph.getCellStyle(cell),
				geometry: graph.getCellGeometry(cell)
			});
		}

		return out;
	}

	function buildPayload(command)
	{
		var inputCfg = command.input || {};
		var payload = {
			commandId: command.id,
			source: 'menu',
			timestamp: new Date().toISOString(),
			selection: getSelectionPayload()
		};

		if (inputCfg.includeDiagramXml === true)
		{
			payload.diagramXml = ui.getFileData(true, null, null, null, true, false);
		}

		if (inputCfg.includeCurrentPage === true && ui.currentPage != null)
		{
			payload.currentPage = {
				id: ui.currentPage.getId ? ui.currentPage.getId() : null,
				name: ui.currentPage.getName ? ui.currentPage.getName() : null
			};
		}

		if (inputCfg.arguments != null)
		{
			payload.arguments = inputCfg.arguments;
		}

		return payload;
	}

	function runUiCommand(cmd)
	{
		var graph = ui.editor.graph;
		var args = cmd.args || {};

		switch (cmd.name)
		{
		case 'reloadDocument':
			window.location.reload();
			break;
		case 'refreshGraph':
			graph.refresh();
			break;
		case 'selectCells':
			if (Array.isArray(args.cellIds))
			{
				var selected = [];
				for (var i = 0; i < args.cellIds.length; i++)
				{
					var c = graph.model.getCell(args.cellIds[i]);
					if (c != null)
					{
						selected.push(c);
					}
				}

				if (selected.length > 0)
				{
					graph.setSelectionCells(selected);
				}
			}
			break;
		case 'showMessage':
			if (args.text == null || String(args.text).trim().length === 0)
			{
				break;
			}
			if (args.level === 'error')
			{
				showError(args.text);
			}
			else
			{
				showInfo(args.text);
			}
			break;
		default:
			writeLog('warn', 'Unknown UI command ignored', {command: cmd});
			break;
		}
	}

	function executeInteractiveCommands(result)
	{
		if (result == null || !Array.isArray(result.commands))
		{
			return;
		}

		for (var i = 0; i < result.commands.length; i++)
		{
			runUiCommand(result.commands[i]);
		}
	}

	async function startManualIndicator(params)
	{
		var request = params || {};
		var remoteIndicator = await requestAsync({
			action: 'startSeafManualIndicator',
			type: request.type === 'percent' ? 'percent' : 'spinner',
			label: request.label || 'SEAF manual operation',
			timeoutMs: Number.isFinite(request.timeoutMs) ? request.timeoutMs : null,
			allowStop: request.allowStop === true
		});
		var id = remoteIndicator && remoteIndicator.indicatorId ? remoteIndicator.indicatorId : String(Date.now());
		var uiIndicator = createIndicatorUi({
			type: request.type === 'percent' ? 'percent' : 'spinner',
			title: request.title || 'SEAF manual operation',
			message: request.message || 'Running...',
			timeoutMs: Number.isFinite(request.timeoutMs) ? request.timeoutMs : null,
			allowStop: request.allowStop === true,
			onStop: (typeof request.onStop === 'function') ? request.onStop : null,
			onTimeout: (typeof request.onTimeout === 'function') ? request.onTimeout : null
		});
		state.manualIndicators[id] = uiIndicator;
		return {indicatorId: id};
	}

	async function stopManualIndicator(indicatorId, reason)
	{
		if (indicatorId == null)
		{
			return;
		}

		try
		{
			await requestAsync({
				action: 'finishSeafManualIndicator',
				indicatorId: indicatorId,
				reason: reason || 'completed'
			});
		}
		catch (e)
		{
			// ignore remote finish errors for local cleanup
		}

		var uiIndicator = state.manualIndicators[indicatorId];
		if (uiIndicator != null)
		{
			uiIndicator.stop();
			delete state.manualIndicators[indicatorId];
		}
	}

	async function pollAsyncJob(jobId, command, indicatorCfg, executionCfg)
	{
		var maxAttempts = Math.max(1, (executionCfg && executionCfg.maxPollAttempts) || (command.execution && command.execution.maxPollAttempts) || 120);
		var intervalMs = Math.max(200, (executionCfg && executionCfg.pollIntervalMs) || (command.execution && command.execution.pollIntervalMs) || 1000);
		var indicator = null;
		if (indicatorCfg && indicatorCfg.enabled)
		{
			indicator = createIndicatorUi({
				type: indicatorCfg.type,
				title: command.title || command.id,
				message: 'Запуск задачи...',
				timeoutMs: indicatorCfg.timeoutMs,
				allowStop: indicatorCfg.allowStop && !Number.isFinite(indicatorCfg.timeoutMs),
				onStop: async function()
				{
					await requestAsync({action: 'cancelSeafPluginJob', jobId: jobId});
				},
				onTimeout: async function()
				{
					await requestAsync({action: 'cancelSeafPluginJob', jobId: jobId});
				}
			});
			state.autoIndicatorsByJob[jobId] = indicator;
		}

		for (var i = 0; i < maxAttempts; i++)
		{
			var status = await requestAsync({
				action: 'pollSeafPluginJob',
				jobId: jobId
			});

			if (indicator != null)
			{
				indicator.update({
					message: status.message || status.phase || 'Выполняется...',
					progress: Number.isFinite(status.progress) ? status.progress : null
				});
			}

			if (status.status === 'completed')
			{
				var completedResult = status.result || {};
				if (indicator != null)
				{
					indicator.update({
						message: 'Обновление завершено',
						progress: 100
					});
					await new Promise(function(resolve)
					{
						window.setTimeout(resolve, 300);
					});
					indicator.stop();
					delete state.autoIndicatorsByJob[jobId];
				}
				executeInteractiveCommands(completedResult);
				if (command && command.id === 'seafSystemUpdatePlugin')
				{
					var updateOutcome = getUpdateUiOutcome(completedResult);
					if (updateOutcome.level === 'error')
					{
						showError(updateOutcome.message);
					}
					else
					{
						showInfo(updateOutcome.message);
					}
				}
				else if (completedResult && typeof completedResult.message === 'string' &&
					completedResult.message.trim().length > 0)
				{
					showInfo(completedResult.message);
				}
				return;
			}
			else if (status.status === 'failed' || status.status === 'timed_out' || status.status === 'cancelled')
			{
				var msg = status.status === 'cancelled' ? 'Операция остановлена' : (status.error || 'unknown error');
				showError(formatCommandError(command.id, msg));
				if (indicator != null)
				{
					indicator.stop();
					delete state.autoIndicatorsByJob[jobId];
				}
				return;
			}

			await new Promise(function(resolve)
			{
				window.setTimeout(resolve, intervalMs);
			});
		}

		if (indicator != null)
		{
			indicator.stop();
			delete state.autoIndicatorsByJob[jobId];
		}
		showError(formatCommandError(command.id, 'async timeout'));
	}

	async function executeCommand(command, source)
	{
		var payload = buildPayload(command);
		payload.source = source;
		var indicatorCfg = getIndicatorConfig(command);

		await writeLog('info', 'Command invocation started', {
			commandId: command.id,
			source: source,
			payload: payload
		});

		try
		{
			var response = await requestAsync({
				action: 'runSeafPluginCommand',
				configPath: state.configPath,
				commandId: command.id,
				payload: payload
			});

			if (response.mode === 'async' && response.jobId)
			{
				pollAsyncJob(response.jobId, command, indicatorCfg, response.execution || null);
				return;
			}

			var result = response.result || {};
			executeInteractiveCommands(result);

			if (result.status === 'error')
			{
				if (typeof result.message === 'string' && result.message.trim().length > 0)
				{
					showError(formatCommandError(command.id, result.message));
				}
			}
			else
			{
				if (typeof result.message === 'string' && result.message.trim().length > 0)
				{
					showInfo(result.message);
				}
			}
		}
		catch (e)
		{
			await writeLog('error', 'Command invocation failed', {
				commandId: command.id,
				source: source,
				error: e.message
			});
			showError(formatCommandError(command.id, e.message));
		}
	}

	async function executeSystemUpdate(source)
	{
		if (state.systemUpdateInProgress)
		{
			showInfo('Обновление уже выполняется. Подождите завершения.');
			return;
		}

		state.systemUpdateInProgress = true;
		var pseudoCommand = {
			id: 'seafSystemUpdatePlugin',
			title: 'Обновить плагин',
			input: {
				includeDiagramXml: false,
				includeCurrentPage: false
			}
		};
		var payload = buildPayload(pseudoCommand);
		payload.source = source || 'menu';

		await writeLog('info', 'System update invocation started', {
			commandId: pseudoCommand.id,
			source: payload.source
		});

		try
		{
			var response = await requestAsync({
				action: 'updateSeafPluginRuntime',
				configPath: state.configPath,
				commandId: 'seafUpdatePlugin',
				payload: payload
			});
			if (response && response.mode === 'async' && response.jobId)
			{
				var updateCommand = {
					id: pseudoCommand.id,
					title: pseudoCommand.title,
					execution: response.execution || {
						pollIntervalMs: 1000,
						maxPollAttempts: 180
					}
				};
				var updateIndicator = response.indicator || {
					enabled: true,
					type: 'percent',
					timeoutMs: 120000,
					allowStop: false
				};
				await pollAsyncJob(response.jobId, updateCommand, updateIndicator, response.execution || null);
				return;
			}

			var result = response.result || {};
			executeInteractiveCommands(result);
			if (result.status === 'error')
			{
				if (typeof result.message === 'string' && result.message.trim().length > 0)
				{
					showError('seafUpdatePlugin: ' + result.message);
				}
			}
			else
			{
				var updateOutcome = getUpdateUiOutcome(result);
				if (updateOutcome.level === 'error')
				{
					showError(updateOutcome.message);
				}
				else
				{
					showInfo(updateOutcome.message);
				}
			}
		}
		catch (e)
		{
			await writeLog('error', 'System update invocation failed', {
				commandId: pseudoCommand.id,
				source: payload.source,
				error: e.message
			});
			showError('seafUpdatePlugin: ' + e.message);
		}
		finally
		{
			state.systemUpdateInProgress = false;
		}
	}

	function contextMatches(command, graph)
	{
		var cfg = (command.menu && command.menu.context) ? command.menu.context : {};
		var target = cfg.target || 'any';
		var selection = graph.getSelectionCells();
		var first = graph.getSelectionCell();

		if (cfg.enabled === false)
		{
			return false;
		}

		if (target === 'selection_non_empty')
		{
			return selection.length > 0;
		}
		else if (target === 'selection_single')
		{
			return selection.length === 1;
		}
		else if (target === 'vertex')
		{
			return first != null && graph.model.isVertex(first);
		}
		else if (target === 'edge')
		{
			return first != null && graph.model.isEdge(first);
		}

		return true;
	}

	function ensureTopLevelMenu(sectionId, title)
	{
		if (ui.menus.get(sectionId) != null)
		{
			return;
		}

		ui.menus.put(sectionId, new Menu(function(){}));
		mxResources.parse(sectionId + '=' + (title || sectionId));

		if (Array.isArray(ui.menus.defaultMenuItems))
		{
			var items = ui.menus.defaultMenuItems.slice();
			if (mxUtils.indexOf(items, sectionId) < 0)
			{
				var helpIdx = mxUtils.indexOf(items, 'help');
				if (helpIdx >= 0)
				{
					items.splice(helpIdx, 0, sectionId);
				}
				else
				{
					items.push(sectionId);
				}
				ui.menus.defaultMenuItems = items;
			}
		}
	}

	function registerMainMenu()
	{
		if (state.mainMenuRegistered)
		{
			return;
		}
		var commands = state.config.commands || [];
		ensureTopLevelMenu('seaf', 'SEAF');
		var customSeafItems = [];
		for (var i = 0; i < commands.length; i++)
		{
			var cmd = commands[i];
			if (cmd.id === 'seafUpdatePlugin')
			{
				continue;
			}
			var mainCfg = (cmd.menu && cmd.menu.main) ? cmd.menu.main : {};
			if (mainCfg.enabled === false)
			{
				continue;
			}
			if (mxUtils.indexOf(customSeafItems, cmd.id) < 0)
			{
				customSeafItems.push(cmd.id);
			}
		}
		var seafMenu = ui.menus.get('seaf');
		if (seafMenu != null)
		{
			var oldFunct = seafMenu.funct;
			seafMenu.funct = function(menuObj, parent)
			{
				oldFunct.apply(this, arguments);
				if (customSeafItems.length > 0)
				{
					ui.menus.addMenuItems(menuObj, ['-'].concat(customSeafItems), parent);
					menuObj.addSeparator(parent);
				}
				ui.menus.addMenuItems(menuObj, ['seafSystemUpdatePlugin'], parent);
				menuObj.addSeparator(parent);
				menuObj.addItem(getRuntimeVersionLabel(), null, null, parent, null, false);
			};
		}

		state.mainMenuRegistered = true;
	}

	function registerContextMenu()
	{
		var oldCreatePopupMenu = ui.menus.createPopupMenu;
		ui.menus.createPopupMenu = function(menu, cell, evt)
		{
			oldCreatePopupMenu.apply(this, arguments);
			var graph = ui.editor.graph;
			var inserted = false;
			var commands = state.config.commands || [];

			for (var i = 0; i < commands.length; i++)
			{
				if (contextMatches(commands[i], graph))
				{
					if (!inserted)
					{
						this.addMenuItems(menu, ['-'], null, evt);
						inserted = true;
					}

					this.addMenuItems(menu, [commands[i].id], null, evt);
				}
			}
		};
	}

	function registerActions()
	{
		if (state.actionsRegistered)
		{
			return;
		}
		mxResources.parse('seafSystemUpdatePlugin=Обновить плагин');
		if (ui.actions.get('seafSystemUpdatePlugin') == null)
		{
			ui.actions.addAction('seafSystemUpdatePlugin', function()
			{
				executeSystemUpdate('menu');
			});
		}

		var commands = state.config.commands || [];
		for (var i = 0; i < commands.length; i++)
		{
			(function(command)
			{
				if (command.id === 'seafUpdatePlugin')
				{
					return;
				}
				state.commandsById[command.id] = command;
			mxResources.parse(command.id + '=' + (command.title || command.id));
				if (ui.actions.get(command.id) == null)
				{
					ui.actions.addAction(command.id, function()
					{
						executeCommand(command, 'menu');
					});
				}
			})(commands[i]);
		}
		state.actionsRegistered = true;
	}

	async function init()
	{
		try
		{
			var loaded = await requestAsync({
				action: 'getSeafPluginConfig',
				configPath: (window.SEAF_PLUGIN_CONFIG_PATH || '')
			});

			if (loaded == null || typeof loaded !== 'object' || loaded.config == null || typeof loaded.config !== 'object')
			{
				throw new Error('Invalid SEAF config response');
			}

			state.configPath = loaded.configPath;
			state.config = loaded.config;
			state.logging = state.config.logging || state.logging;
			state.runtimeVersion = await detectRuntimeVersion();

			await writeLog('info', 'Plugin initialization started', {
				configPath: state.configPath,
				commandsCount: Array.isArray(state.config.commands) ? state.config.commands.length : 0
			});

			registerActions();
			registerMainMenu();
			registerContextMenu();
			window.SEAF_PLUGIN_API = {
				startIndicator: startManualIndicator,
				stopIndicator: stopManualIndicator
			};

			await writeLog('info', 'Plugin initialization finished', {ok: true});
		}
		catch (e)
		{
			showError('SEAF plugin initialization failed: ' + e.message);
			try
			{
				console.error('SEAF plugin init failed', e);
			}
			catch (ignored)
			{
				// ignore
			}
		}
	}

	init();
});
