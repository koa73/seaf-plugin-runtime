#!/usr/bin/env python3
"""P41 Export: build {schema: {OID: data}} from diagram and write YAML to output path or directory."""

from __future__ import annotations

from typing import Any, Dict, List

from lib.config.env_config import build_env_config
from lib.io import build_error_policy_payload, get_payload, read_request, write_response
from lib.logging import build_script_logger
from lib.main_menu.export_helpers import build_export_by_schema, resolve_output_path, write_export_outputs

HANDLER = "main_menu.export"
OUTPUT_MISSING_MESSAGE = (
    "Не указан Output SEAF file или каталог. Задайте путь в SEAF → Edit Config."
)
OUTPUT_MISSING_POPUP = (
    "Не указан Output SEAF file или каталог. Откройте SEAF → Edit Config и укажите выходной путь."
)


def _output_missing_response(logger) -> int:
    logger.error(OUTPUT_MISSING_MESSAGE)
    return write_response(
        status="error",
        message=OUTPUT_MISSING_MESSAGE,
        payload=build_error_policy_payload(
            {"handler": HANDLER, "reason": "output_file_missing"},
            user_visible=True,
        ),
        commands=[
            {
                "name": "showMessage",
                "args": {"level": "error", "text": OUTPUT_MISSING_POPUP},
            }
        ],
        errors=["outputSeafFile is empty"],
    )


def _write_error_response(logger, message: str, reason: str) -> int:
    logger.error(message)
    return write_response(
        status="error",
        message=message,
        payload=build_error_policy_payload(
            {"handler": HANDLER, "reason": reason},
            user_visible=True,
        ),
        commands=[
            {
                "name": "showMessage",
                "args": {"level": "error", "text": message},
            }
        ],
        errors=[message],
    )


def main() -> int:
    request = read_request()
    payload = get_payload(request)
    logger = build_script_logger(payload)
    env = build_env_config(request)

    output_path = resolve_output_path(env)
    if not output_path:
        return _output_missing_response(logger)

    schema_objects = payload.get("schemaObjects")
    if not isinstance(schema_objects, list):
        schema_objects = []

    export_map, warnings = build_export_by_schema(schema_objects)

    try:
        written_files, write_mode = write_export_outputs(export_map, output_path)
    except OSError as exc:
        message = f"Не удалось записать export в {output_path} ({exc})"
        return _write_error_response(logger, message, "output_file_write_failed")

    schema_count = len(export_map)
    object_count = sum(len(bucket) for bucket in export_map.values())
    logger.info(
        {
            "handler": HANDLER,
            "invoked": True,
            "commandId": request.get("commandId"),
            "source": payload.get("source"),
            "outputPath": output_path,
            "writeMode": write_mode,
            "writtenFiles": written_files,
            "schemaCount": schema_count,
            "objectCount": object_count,
            "warnings": warnings,
        }
    )

    if write_mode == "directory":
        success_message = f"Export written: {len(written_files)} YAML file(s) in {output_path}"
    else:
        success_message = f"Export written to {written_files[0]}"

    return write_response(
        status="success",
        message=success_message,
        payload={
            "handler": HANDLER,
            "outputPath": output_path,
            "writeMode": write_mode,
            "outputFiles": written_files,
            "schemaCount": schema_count,
            "objectCount": object_count,
            "warnings": warnings,
        },
        commands=[],
        errors=[],
    )


if __name__ == "__main__":
    raise SystemExit(main())
