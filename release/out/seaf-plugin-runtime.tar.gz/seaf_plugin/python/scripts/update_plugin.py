#!/usr/bin/env python3
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


LEVEL_MAP = {"debug": 10, "info": 20, "warn": 30, "error": 40}


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def parse_scalar(raw: str) -> Any:
    raw = raw.strip()
    if raw == "":
        return ""
    if raw.lower() == "true":
        return True
    if raw.lower() == "false":
        return False
    if raw.lower() in ("null", "~"):
        return None
    if (raw.startswith('"') and raw.endswith('"')) or (raw.startswith("'") and raw.endswith("'")):
        return raw[1:-1]
    return raw


def parse_yaml_subset(yaml_text: str) -> Dict[str, Any]:
    root: Dict[str, Any] = {}
    stack: list[Tuple[int, Dict[str, Any]]] = [(-1, root)]

    for line in yaml_text.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue

        if line.lstrip().startswith("- "):
            continue

        match = re.match(r"^(\s*)([A-Za-z0-9_]+):\s*(.*)$", line)
        if not match:
            continue

        indent = len(match.group(1))
        key = match.group(2)
        value_raw = match.group(3)

        while len(stack) > 1 and indent <= stack[-1][0]:
            stack.pop()

        current = stack[-1][1]
        if value_raw == "":
            nxt: Dict[str, Any] = {}
            current[key] = nxt
            stack.append((indent, nxt))
        else:
            current[key] = parse_scalar(value_raw)

    return root


class Logger:
    def __init__(self, level: str, file_path: Path):
        normalized = (level or "info").strip().lower()
        self.threshold = LEVEL_MAP.get(normalized, 20)
        self.file_path = file_path

    def log(self, level: str, event: str, data: Optional[Dict[str, Any]] = None) -> None:
        lvl = (level or "info").strip().lower()
        if LEVEL_MAP.get(lvl, 20) < self.threshold:
            return

        payload = {
            "ts": now_iso(),
            "level": lvl,
            "event": event,
            "data": data or {},
        }
        line = json.dumps(payload, ensure_ascii=False)
        try:
            self.file_path.parent.mkdir(parents=True, exist_ok=True)
            with self.file_path.open("a", encoding="utf-8") as fp:
                fp.write(line + "\n")
        except Exception:
            # Logging must not break update flow.
            pass


def resolve_paths(script_path: Path) -> Dict[str, Path]:
    seaf_plugin_dir = script_path.parents[2]
    plugins_dir = seaf_plugin_dir.parent
    plugin_yaml = seaf_plugin_dir / "conf" / "plugin.yaml"
    plugin_js = plugins_dir / "seaf.plugin.js"
    return {
        "seaf_plugin_dir": seaf_plugin_dir,
        "plugins_dir": plugins_dir,
        "plugin_yaml": plugin_yaml,
        "plugin_js": plugin_js,
    }


def read_json(url: str) -> Dict[str, Any]:
    req = urllib.request.Request(url, headers={"Accept": "application/vnd.github+json", "User-Agent": "seaf-plugin-updater"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def download_file(url: str, target: Path) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "seaf-plugin-updater"})
    with urllib.request.urlopen(req, timeout=120) as resp:
        target.write_bytes(resp.read())


def read_runtime_version_from_dir(runtime_dir: Path) -> Optional[str]:
    version_file = runtime_dir / "version.json"
    if not version_file.exists():
        return None
    try:
        parsed = json.loads(version_file.read_text(encoding="utf-8"))
        if isinstance(parsed, dict):
            ver = parsed.get("version")
            if isinstance(ver, str) and ver.strip():
                return ver.strip()
    except Exception:
        return None
    return None


def pick_extract_root(extract_dir: Path) -> Path:
    if (extract_dir / "seaf.plugin.js").exists() and (extract_dir / "seaf_plugin").exists():
        return extract_dir
    entries = [p for p in extract_dir.iterdir() if p.is_dir()]
    if len(entries) == 1 and (entries[0] / "seaf.plugin.js").exists() and (entries[0] / "seaf_plugin").exists():
        return entries[0]
    raise RuntimeError("Archive structure invalid: expected seaf.plugin.js and seaf_plugin directory")


def apply_runtime(extract_root: Path, plugins_dir: Path, logger: Logger) -> None:
    new_plugin_js = extract_root / "seaf.plugin.js"
    new_runtime_dir = extract_root / "seaf_plugin"
    if not new_plugin_js.exists() or not new_runtime_dir.exists():
        raise RuntimeError("Extracted archive does not contain seaf.plugin.js and seaf_plugin")

    target_plugin_js = plugins_dir / "seaf.plugin.js"
    target_runtime_dir = plugins_dir / "seaf_plugin"
    backup_plugin_js = plugins_dir / ".seaf.plugin.js.bak"
    backup_runtime_dir = plugins_dir / ".seaf_plugin.bak"

    # Cleanup stale backups from interrupted runs.
    if backup_plugin_js.exists():
        backup_plugin_js.unlink()
    if backup_runtime_dir.exists():
        shutil.rmtree(backup_runtime_dir)

    try:
        if target_plugin_js.exists():
            target_plugin_js.rename(backup_plugin_js)
        if target_runtime_dir.exists():
            target_runtime_dir.rename(backup_runtime_dir)

        shutil.copy2(new_plugin_js, target_plugin_js)
        shutil.copytree(new_runtime_dir, target_runtime_dir)

        if backup_plugin_js.exists():
            backup_plugin_js.unlink()
        if backup_runtime_dir.exists():
            shutil.rmtree(backup_runtime_dir)
    except Exception as exc:
        logger.log("error", "apply_failed", {"error": str(exc)})
        try:
            if target_plugin_js.exists():
                target_plugin_js.unlink()
            if target_runtime_dir.exists():
                shutil.rmtree(target_runtime_dir)
            if backup_plugin_js.exists():
                backup_plugin_js.rename(target_plugin_js)
            if backup_runtime_dir.exists():
                backup_runtime_dir.rename(target_runtime_dir)
        except Exception as rollback_exc:
            logger.log("error", "rollback_failed", {"error": str(rollback_exc)})
        raise


def ensure_git_available() -> None:
    result = subprocess.run(["git", "--version"], capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise RuntimeError("На ПК не установлен клиент git")


def fetch_archive_ssh(update_cfg: Dict[str, Any], temp_root: Path, logger: Logger, seaf_plugin_dir: Path) -> Tuple[Path, Dict[str, Any]]:
    repo_ssh = str(update_cfg.get("gitRepoSsh", "") or "").strip()
    git_ref = str(update_cfg.get("gitRef", "master") or "master").strip()
    asset_path = str(update_cfg.get("assetPath", "release/out/seaf-plugin-runtime.tar.gz") or "").strip()
    ssh_cfg = update_cfg.get("ssh") if isinstance(update_cfg.get("ssh"), dict) else {}
    key_rel = str(ssh_cfg.get("privateKeyPath", "") or "").strip()

    if not repo_ssh:
        raise RuntimeError("Не задан update.gitRepoSsh в plugin.yaml")
    if not key_rel:
        raise RuntimeError("Не задан путь к приватному ключу update.ssh.privateKeyPath")

    ensure_git_available()

    clone_dir = temp_root / "repo"
    key_path = (seaf_plugin_dir / "conf" / key_rel).resolve() if not os.path.isabs(key_rel) else Path(key_rel)
    if not key_path.exists():
        raise RuntimeError(f"Не найден приватный ключ SSH: {key_path}")

    env = os.environ.copy()
    env["GIT_SSH_COMMAND"] = f"ssh -i \"{key_path}\" -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new"

    ls_remote = subprocess.run(["git", "ls-remote", repo_ssh], capture_output=True, text=True, check=False, env=env)
    if ls_remote.returncode != 0:
        raise RuntimeError("Нет доступа к репозиторию по SSH")

    clone = subprocess.run(["git", "clone", "--depth", "1", "--branch", git_ref, repo_ssh, str(clone_dir)],
                           capture_output=True, text=True, check=False, env=env)
    if clone.returncode != 0:
        raise RuntimeError(f"Ошибка git clone: {clone.stderr.strip() or clone.stdout.strip()}")

    archive_path = clone_dir / asset_path
    if not archive_path.exists():
        raise RuntimeError(f"В репозитории не найден файл ассета: {asset_path}")

    local_archive = temp_root / "seaf-plugin-runtime.tar.gz"
    shutil.copy2(archive_path, local_archive)
    logger.log("info", "ssh_archive_prepared", {"repo": repo_ssh, "ref": git_ref, "assetPath": asset_path})
    return local_archive, {"mode": "ssh_git", "repoSsh": repo_ssh, "ref": git_ref, "assetPath": asset_path}


def fetch_archive_release(update_cfg: Dict[str, Any], temp_root: Path) -> Tuple[Path, Dict[str, Any]]:
    repo = str(update_cfg.get("repo", "") or "").strip()
    asset_name = str(update_cfg.get("assetName", "seaf-plugin-runtime.tar.gz") or "").strip()
    tag = str(update_cfg.get("tag", "") or "").strip()
    api_base = str(update_cfg.get("apiBaseUrl", "https://api.github.com") or "").strip().rstrip("/")

    if not re.match(r"^[^/\s]+/[^/\s]+$", repo):
        raise RuntimeError(f"Invalid repo format: {repo}. Expected owner/name")

    if tag:
        release_url = f"{api_base}/repos/{repo}/releases/tags/{urllib.parse.quote(tag)}"
    else:
        release_url = f"{api_base}/repos/{repo}/releases/latest"

    release = read_json(release_url)
    assets = release.get("assets") if isinstance(release, dict) else None
    asset = None
    if isinstance(assets, list):
        for item in assets:
            if isinstance(item, dict) and item.get("name") == asset_name and item.get("browser_download_url"):
                asset = item
                break

    if asset is None:
        raise RuntimeError(f"Release asset \"{asset_name}\" not found")

    archive_path = temp_root / asset_name
    download_file(str(asset["browser_download_url"]), archive_path)
    return archive_path, {
        "mode": "github_release",
        "repo": repo,
        "tag": release.get("tag_name") if isinstance(release, dict) else tag or "latest",
        "asset": asset_name,
    }


def build_response(status: str, message: str, payload: Dict[str, Any], commands: Optional[list] = None,
                   errors: Optional[list] = None) -> Dict[str, Any]:
    return {
        "status": status,
        "message": message,
        "payload": payload,
        "commands": commands or [],
        "errors": errors or [],
    }


def main() -> int:
    raw = sys.stdin.read()
    req = json.loads(raw) if raw.strip() else {}

    paths = resolve_paths(Path(__file__).resolve())
    plugin_yaml = paths["plugin_yaml"]
    if not plugin_yaml.exists():
        out = build_response("error", f"Не найден plugin.yaml: {plugin_yaml}", {}, errors=["config_not_found"])
        sys.stdout.write(json.dumps(out, ensure_ascii=False))
        return 0

    cfg = parse_yaml_subset(plugin_yaml.read_text(encoding="utf-8"))
    logging_cfg = cfg.get("logging") if isinstance(cfg.get("logging"), dict) else {}
    update_cfg = cfg.get("update") if isinstance(cfg.get("update"), dict) else {}
    logger = Logger(str(logging_cfg.get("level", "info") or "info"),
                    (plugin_yaml.parent / str(logging_cfg.get("filePath", "../logs/seaf-plugin.log"))).resolve())

    correlation_id = f"upd-{int(datetime.now(timezone.utc).timestamp())}"
    logger.log("info", "update_started", {"correlationId": correlation_id, "commandId": req.get("commandId")})

    if update_cfg.get("enabled", True) is False:
        msg = "SEAF runtime update is disabled in plugin.yaml (update.enabled=false)"
        logger.log("warn", "update_disabled", {"correlationId": correlation_id})
        out = build_response("error", msg, {"status": "failed"}, errors=["update_disabled"])
        sys.stdout.write(json.dumps(out, ensure_ascii=False))
        return 0

    mode = str(update_cfg.get("mode", "github_release") or "github_release").strip()
    plugins_dir = paths["plugins_dir"]
    local_version = read_runtime_version_from_dir(plugins_dir / "seaf_plugin" / "runtime")
    logger.log("info", "config_resolved", {"correlationId": correlation_id, "mode": mode, "pluginsDir": str(plugins_dir)})

    temp_root_path = Path(tempfile.mkdtemp(prefix=".seaf_runtime_update_", dir=str(plugins_dir)))
    extract_dir = temp_root_path / "extract"
    extract_dir.mkdir(parents=True, exist_ok=True)

    try:
        if mode == "ssh_git":
            archive_path, source_info = fetch_archive_ssh(update_cfg, temp_root_path, logger, paths["seaf_plugin_dir"])
        else:
            archive_path, source_info = fetch_archive_release(update_cfg, temp_root_path)
        logger.log("info", "download_finished", {"correlationId": correlation_id, "archive": str(archive_path), "source": source_info})

        with tarfile.open(archive_path, "r:gz") as tf:
            tf.extractall(extract_dir)
        logger.log("info", "extract_finished", {"correlationId": correlation_id, "extractDir": str(extract_dir)})

        extract_root = pick_extract_root(extract_dir)
        new_version = read_runtime_version_from_dir(extract_root / "seaf_plugin" / "runtime")
        logger.log("info", "version_compared", {
            "correlationId": correlation_id,
            "localVersion": local_version,
            "newVersion": new_version,
        })

        if local_version and new_version and local_version == new_version:
            out = build_response(
                "success",
                f"Установлена актуальная версия {local_version}",
                {"status": "already_up_to_date", "version": local_version, "source": source_info},
            )
            sys.stdout.write(json.dumps(out, ensure_ascii=False))
            return 0

        apply_runtime(extract_root, plugins_dir, logger)
        installed_version = read_runtime_version_from_dir(plugins_dir / "seaf_plugin" / "runtime")
        final_version = installed_version or new_version or local_version or "unknown"
        logger.log("info", "apply_finished", {"correlationId": correlation_id, "version": final_version})

        out = build_response(
            "success",
            f"Версия плагина обновлена до версии {final_version}",
            {"status": "updated", "version": final_version, "source": source_info},
            commands=[{"name": "reloadDocument", "args": {}}],
        )
        sys.stdout.write(json.dumps(out, ensure_ascii=False))
        return 0
    except urllib.error.HTTPError as exc:
        message = f"HTTP error: {exc.code} {exc.reason}"
        logger.log("error", "update_failed", {"correlationId": correlation_id, "error": message})
        out = build_response("error", message, {"status": "failed"}, errors=["http_error"])
        sys.stdout.write(json.dumps(out, ensure_ascii=False))
        return 0
    except Exception as exc:
        message = str(exc)
        logger.log("error", "update_failed", {"correlationId": correlation_id, "error": message})
        out = build_response("error", message, {"status": "failed"}, errors=["update_failed"])
        sys.stdout.write(json.dumps(out, ensure_ascii=False))
        return 0
    finally:
        shutil.rmtree(temp_root_path, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
