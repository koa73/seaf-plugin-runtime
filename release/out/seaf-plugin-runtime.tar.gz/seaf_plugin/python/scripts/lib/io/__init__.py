"""I/O helpers for SEAF runtime scripts."""

