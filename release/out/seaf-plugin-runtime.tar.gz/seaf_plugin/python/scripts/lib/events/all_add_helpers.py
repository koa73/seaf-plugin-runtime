"""Support functions for the all_add event handler."""

from __future__ import annotations

from typing import Any, Callable, Dict, List

from lib.oid import build_conflict_table_rows


def log_event_items(
    handler: str, event: Dict[str, Any], items: List[Dict[str, Any]], emit_info: Callable[[Dict[str, Any]], None]
) -> None:
    """Log each event item with page and geometry metadata."""
    page = event.get("page") or {}
    for item in items:
        geometry = item.get("geometry") or {}
        data = item.get("data") or {}
        object_id = item.get("objectId") or item.get("id")
        emit_info(
            {
                "handler": handler,
                "objectId": object_id,
                "pageId": page.get("id"),
                "pageName": page.get("name"),
                "geometry": {
                    "x": geometry.get("x"),
                    "y": geometry.get("y"),
                    "width": geometry.get("width"),
                    "height": geometry.get("height"),
                },
                "data": data,
            }
        )


def resolve_company_prefix(payload: Dict[str, Any], fallback: str = "company") -> str:
    """Resolve company prefix from arguments/env with deterministic fallback."""
    company_prefix = str((payload.get("arguments") or {}).get("companyPrefix") or "").strip()
    if company_prefix:
        return company_prefix

    env = payload.get("env") or {}
    company_prefix = str(env.get("companyPrefix") or "").strip()
    if company_prefix:
        return company_prefix

    return fallback


def build_collision_message(conflicts: List[Dict[str, Any]]) -> str:
    """Build user-facing collisions message with a tabular payload."""
    return (
        "Обнаружены коллизии OID при добавлении/импорте. "
        "Автоматическая дедупликация не выполняется. "
        "Требуется ручной разбор.\n\n"
        + build_conflict_table_rows(conflicts)
    )


def build_update_stencil_data_bulk_command(page_id: Any, updates: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Build command payload for batched stencil data updates."""
    return {
        "name": "updateStencilDataBulk",
        "args": {
            "pageId": page_id,
            "updates": updates,
        },
    }


def build_ensure_auto_layer_command(page_id: Any) -> Dict[str, Any]:
    """Build command payload that guarantees visible SEAF auto layer."""
    return {
        "name": "ensureLayer",
        "args": {
            "pageId": page_id,
            "layerName": "SEAF_AUTO_LAYER",
            "makeVisible": True,
        },
    }


def to_bool_with_default(value: Any, default: bool = True) -> bool:
    """Convert mixed input into bool with explicit default for missing values."""
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"false", "0", "no", "off"}:
        return False
    if text in {"true", "1", "yes", "on"}:
        return True
    return default


def resolve_item_layer_name(item: Dict[str, Any], fallback: str = "unknown") -> str:
    """Resolve layer name with priority: type -> title -> fallback."""
    data = item.get("data") or {}
    if "type" in data or "type" in item:
        type_value = data.get("type") if "type" in data else item.get("type")
        type_text = str(type_value or "").strip()
        return type_text if type_text else "Unknown"

    for raw in (data.get("title"), item.get("title"), data.get("label"), item.get("label")):
        text = str(raw or "").strip()
        if text:
            return text
    return fallback


def is_layer_enabled_for_item(item: Dict[str, Any], default: bool = True) -> bool:
    """Resolve whether layer-routing is enabled for the item."""
    data = item.get("data") or {}
    if "layer" in item:
        return to_bool_with_default(item.get("layer"), default)
    if "layer" in data:
        return to_bool_with_default(data.get("layer"), default)
    return default


def build_move_objects_to_layer_command(page_id: Any, layer_name: str, object_ids: List[str]) -> Dict[str, Any]:
    """Build command payload to move explicit objects to a layer."""
    return {
        "name": "moveObjectsToLayer",
        "args": {
            "pageId": page_id,
            "layerName": layer_name,
            "objectIds": object_ids,
            "makeVisible": True,
        },
    }
