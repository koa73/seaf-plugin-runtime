"""Helpers to build UI commands for page links."""

from __future__ import annotations

from typing import Any, Dict


def build_create_page_command(title: str, select_created: bool = True) -> Dict[str, Any]:
    """Build UI command that creates a page using draw.io page API."""
    return {
        "name": "createPage",
        "args": {
            "title": title,
            "selectCreated": select_created,
        },
    }


def build_link_to_page_command(object_id: str, title: str) -> Dict[str, Any]:
    """Build UI command that links source stencil to page created by title."""
    return {
        "name": "setCellLinkToPage",
        "args": {
            "objectId": object_id,
            "targetPageTitle": title,
        },
    }

