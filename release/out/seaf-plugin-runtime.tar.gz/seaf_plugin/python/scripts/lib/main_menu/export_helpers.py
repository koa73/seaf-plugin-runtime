"""Build schema/OID export dictionary and resolve output file path."""

from __future__ import annotations

from typing import Any, Dict, List, Sequence, Tuple

EXPORT_EXCLUDED = frozenset({"id", "label", "link", "OID", "schema"})


def sanitize_export_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """Return export payload attributes without service keys."""
    if not isinstance(data, dict):
        return {}
    out: Dict[str, Any] = {}
    for key, value in data.items():
        normalized_key = str(key).strip()
        if not normalized_key or normalized_key in EXPORT_EXCLUDED:
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            out[normalized_key] = value
        else:
            out[normalized_key] = str(value)
    return out


def resolve_output_path(env: Dict[str, Any]) -> str:
    """Resolve output file path from env (Edit Config), with same-file fallback."""
    output_raw = str(env.get("outputSeafFile") or "").strip()
    use_same = env.get("useSameOutputFile") is True
    if output_raw:
        return output_raw
    if use_same:
        return str(env.get("inputSeafFile") or "").strip()
    return ""


def build_export_by_schema(
    objects: Sequence[Dict[str, Any]],
) -> Tuple[Dict[str, Dict[str, Dict[str, Any]]], List[str]]:
    """Group schema objects into {schema: {OID: {attrs}}}."""
    export_map: Dict[str, Dict[str, Dict[str, Any]]] = {}
    warnings: List[str] = []

    for item in objects:
        if not isinstance(item, dict):
            continue
        schema = str(item.get("schema") or "").strip()
        oid = str(item.get("oid") or item.get("OID") or "").strip()
        if not schema:
            continue
        if not oid:
            object_id = str(item.get("objectId") or item.get("id") or "").strip()
            warnings.append(
                f"skip object without OID: schema={schema}, objectId={object_id or 'unknown'}"
            )
            continue

        raw_data = item.get("data") if isinstance(item.get("data"), dict) else {}
        sanitized = sanitize_export_data(raw_data)
        schema_bucket = export_map.setdefault(schema, {})
        if oid in schema_bucket and schema_bucket[oid] != sanitized:
            warnings.append(f"OID data conflict for schema={schema}, OID={oid}; using latest")
        schema_bucket[oid] = sanitized

    return export_map, warnings
