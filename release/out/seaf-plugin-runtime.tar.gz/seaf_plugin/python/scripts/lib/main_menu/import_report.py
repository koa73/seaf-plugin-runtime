"""Import run report aggregation and structured logging (INFO / DEBUG)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from lib.logging import ScriptLogger

HANDLER = "main_menu.import"


@dataclass
class ImportReport:
    """Aggregated diagnostics for import pipeline."""

    files_discovered: List[str] = field(default_factory=list)
    files_read: List[str] = field(default_factory=list)
    loaded: List[Dict[str, Any]] = field(default_factory=list)
    matched: List[Dict[str, Any]] = field(default_factory=list)
    updates: List[Dict[str, Any]] = field(default_factory=list)
    unmatched_in_diagram: Dict[str, List[str]] = field(default_factory=dict)
    skipped_duplicate: List[Dict[str, Any]] = field(default_factory=list)
    skipped_schema: List[Dict[str, Any]] = field(default_factory=list)
    files_invalid: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    ui_result: Dict[str, Any] = field(default_factory=dict)

    @property
    def loaded_from_files_count(self) -> int:
        return len(self.files_read)

    @property
    def loaded_object_count(self) -> int:
        return len(self.loaded)

    @property
    def matched_on_diagram_count(self) -> int:
        return len(self.matched)

    @property
    def updated_count(self) -> int:
        updated = self.ui_result.get("updatedCells")
        if isinstance(updated, int):
            return updated
        return len(self.updates)


def log_import_report(logger: ScriptLogger, report: ImportReport) -> None:
    """Write summary (INFO) and detail (DEBUG) report."""
    summary: Dict[str, Any] = {
        "handler": HANDLER,
        "reportLevel": "summary",
        "loadedFromFilesCount": report.loaded_from_files_count,
        "loadedObjectCount": report.loaded_object_count,
        "matchedOnDiagramCount": report.matched_on_diagram_count,
        "updatedCount": report.updated_count,
        "unmatchedInDiagram": report.unmatched_in_diagram,
        "invalidFileCount": len(report.files_invalid),
        "skippedSchemaCount": len(report.skipped_schema),
        "duplicateOidCount": len(report.skipped_duplicate),
        "warnings": list(report.warnings),
        "errors": list(report.errors),
    }
    logger.info(summary)

    detail = {
        "handler": HANDLER,
        "reportLevel": "detail",
        "filesDiscovered": list(report.files_discovered),
        "filesRead": list(report.files_read),
        "filesInvalid": list(report.files_invalid),
        "loaded": list(report.loaded),
        "matched": list(report.matched),
        "updates": list(report.updates),
        "unmatchedInDiagram": report.unmatched_in_diagram,
        "skippedDuplicate": list(report.skipped_duplicate),
        "skippedSchema": list(report.skipped_schema),
        "uiResult": dict(report.ui_result),
    }
    logger.debug(detail)

