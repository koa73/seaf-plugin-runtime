"""Helpers to read environment-style config from SEAF payload."""

from __future__ import annotations

from typing import Any, Dict


def build_env_config(request: Dict[str, Any]) -> Dict[str, Any]:
    """Return env configuration passed from desktop runtime.

    The runtime injects these values from `conf/env.yaml` into
    `REQUEST.payload.env` and mirrors them to `REQUEST.payload.arguments`.
    """
    payload = request.get("payload") or {}
    payload_env = payload.get("env") or {}
    payload_args = payload.get("arguments") or {}

    return {
        "inputFile": payload_env.get("inputFile", payload_args.get("inputFile", "")),
        "outputFile": payload_env.get("outputFile", payload_args.get("outputFile", "")),
        "processingMode": payload_env.get("processingMode", payload_args.get("processingMode", "fast")),
        "overwriteExisting": payload_env.get("overwriteExisting", payload_args.get("overwriteExisting", False)),
        "outputFormat": payload_env.get("outputFormat", payload_args.get("outputFormat", "json")),
    }

