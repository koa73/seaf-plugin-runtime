#!/usr/bin/env python3
import unittest

from lib.oid.conflicts import collect_import_conflicts, normalize_known_oid_entry


class OidConflictsContractTests(unittest.TestCase):
    def test_normalize_known_oid_entry_accepts_object_shape(self):
        entry = {"objectIds": ["id-1", "id-2"]}
        self.assertEqual(normalize_known_oid_entry(entry), ["id-1", "id-2"])

    def test_normalize_known_oid_entry_accepts_list_shape(self):
        entry = ["id-1", "id-2"]
        self.assertEqual(normalize_known_oid_entry(entry), ["id-1", "id-2"])

    def test_collect_import_conflicts_handles_object_shape(self):
        items = [{"objectId": "new-1", "schema": "schema.a", "data": {"OID": "corp.a.1"}}]
        known = {"corp.a.1": {"objectIds": ["existing-1"]}}
        conflicts = collect_import_conflicts(items, known)
        self.assertEqual(len(conflicts), 1)
        self.assertEqual(conflicts[0]["conflictWithCellId"], "existing-1")

    def test_collect_import_conflicts_handles_list_shape(self):
        items = [{"objectId": "new-1", "schema": "schema.a", "data": {"OID": "corp.a.1"}}]
        known = {"corp.a.1": ["existing-1"]}
        conflicts = collect_import_conflicts(items, known)
        self.assertEqual(len(conflicts), 1)
        self.assertEqual(conflicts[0]["conflictWithCellId"], "existing-1")


if __name__ == "__main__":
    unittest.main()
