#!/usr/bin/env python3
import unittest

import all_add


class AllAddOidTests(unittest.TestCase):
    def test_schema_code_extracts_last_two_segments(self):
        self.assertEqual(all_add._schema_code("seaf.company.ta.services.dc_azs"), "services.dc_azs")

    def test_schema_code_fallback_unknown(self):
        self.assertEqual(all_add._schema_code(""), "unknown")
        self.assertEqual(all_add._schema_code("seaf"), "unknown")

    def test_next_oid_uses_max_sequence(self):
        known = {
            "corp.services.dc_azs.1": {"objectIds": ["a"]},
            "corp.services.dc_azs.7": {"objectIds": ["b"]},
            "corp.services.other.12": {"objectIds": ["c"]},
        }
        reserved = {}
        oid = all_add._next_oid("corp", "seaf.company.ta.services.dc_azs", known, reserved)
        self.assertEqual(oid, "corp.services.dc_azs.8")

    def test_collect_import_conflicts_reports_existing_oid(self):
        items = [
            {
                "id": "new-1",
                "objectId": "new-1",
                "schema": "seaf.company.ta.services.dc_azs",
                "data": {"OID": "corp.services.dc_azs.3"},
            }
        ]
        known = {"corp.services.dc_azs.3": {"objectIds": ["old-1"]}}
        conflicts = all_add._collect_import_conflicts(items, known)
        self.assertEqual(len(conflicts), 1)
        self.assertEqual(conflicts[0]["cellId"], "new-1")
        self.assertEqual(conflicts[0]["conflictWithCellId"], "old-1")


if __name__ == "__main__":
    unittest.main()
