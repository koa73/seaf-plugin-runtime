#!/usr/bin/env python3
import unittest

from events.all_add import build_commands
from lib.oid import collect_import_conflicts, next_oid, schema_code


class AllAddOidTests(unittest.TestCase):
    def test_schema_code_extracts_last_two_segments(self):
        self.assertEqual(schema_code("seaf.company.ta.services.dc_azs"), "services.dc_azs")

    def test_schema_code_fallback_unknown(self):
        self.assertEqual(schema_code(""), "unknown")
        self.assertEqual(schema_code("seaf"), "unknown")

    def test_next_oid_uses_max_sequence(self):
        known = {
            "corp.services.dc_azs.1": {"objectIds": ["a"]},
            "corp.services.dc_azs.7": {"objectIds": ["b"]},
            "corp.services.other.12": {"objectIds": ["c"]},
        }
        reserved = {}
        oid = next_oid("corp", "seaf.company.ta.services.dc_azs", known, reserved)
        self.assertEqual(oid, "corp.services.dc_azs.8")

    def test_collect_import_conflicts_reports_existing_oid(self):
        items = [
            {
                "id": "new-1",
                "objectId": "new-1",
                "schema": "seaf.company.ta.services.dc_azs",
                "data": {"OID": "corp.services.dc_azs.3"},
            }
        ]
        known = {"corp.services.dc_azs.3": {"objectIds": ["old-1"]}}
        conflicts = collect_import_conflicts(items, known)
        self.assertEqual(len(conflicts), 1)
        self.assertEqual(conflicts[0]["cellId"], "new-1")
        self.assertEqual(conflicts[0]["conflictWithCellId"], "old-1")

    def test_orchestrator_builds_bulk_command(self):
        payload = {
            "arguments": {"companyPrefix": "corp"},
            "event": {
                "page": {"id": "p1"},
                "index": {"byOid": {"corp.services.dc_azs.2": {"objectIds": ["old"]}}},
                "items": [
                    {"id": "n1", "objectId": "n1", "schema": "seaf.company.ta.services.dc_azs", "data": {}}
                ],
            },
        }
        commands = build_commands(payload)
        command_names = [c.get("name") for c in commands]
        self.assertIn("updateStencilDataBulk", command_names)
        self.assertIn("ensureLayer", command_names)


if __name__ == "__main__":
    unittest.main()
